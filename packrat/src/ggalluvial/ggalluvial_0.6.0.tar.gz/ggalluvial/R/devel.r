#' Deprecated functions
#' 
#' These functions are deprecated in the current version and will be removed for
#' the eventual CRAN release.
#' 
#' @name ggalluvial-deprecated
#' @keywords internal
NULL

release_questions <- function() {
  c(
    "Have previous CRAN NOTEs been addressed?"
  )
}
